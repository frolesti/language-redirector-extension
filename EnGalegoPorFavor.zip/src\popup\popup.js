﻿document.addEventListener('DOMContentLoaded', () => {
  // Forcem l'idioma en instalÂ·lar/obrir
  chrome.storage.sync.set({ preferredLanguage: 'gl' });

  // BotÃ³ de donaciÃ³
  const donateBtn = document.getElementById('donate');
  if (donateBtn) {
    donateBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://frolesti.aixeta.cat/ca' });
    });
  }

  // BotÃ³ de reportar error
  const reportBtn = document.getElementById('report');
  if (reportBtn) {
    reportBtn.addEventListener('click', () => {
      chrome.tabs.update({ url: 'mailto:frolesti4@gmail.com?subject=Erro%20-%20En%20Galego%20Por%20Favor' });
    });
  }
});

